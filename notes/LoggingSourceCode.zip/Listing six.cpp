	enum severity_type
	{
		debug = 1,
		error,
		warning
	};

