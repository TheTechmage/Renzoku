
#define DATA_SUBMISSION (0)
#define DATA_BURST      (1)
#define DATA_POINTS     (2)

#define IDX(x,y) ((x) * DATA_POINTS + (y))

