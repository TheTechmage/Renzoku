#include<stdio.h>
#include<stdlib.h>
#include"sched_algol.h"

int main(int argc, char *argv[]) {
	int i, j, value, len, count, *data;

	i = 0;
	count = 0;
	len = 0;
	data = NULL;

	while ( fscanf(stdin, "%d", &value) == 1 ) {
		if ( i == 0 && len == count ) {
			len = (len > 0) ? len * 2 : 1;
			data = realloc(data, sizeof(int) * DATA_POINTS * len);
		}
		data[IDX(count,i)] = value;
		i = (i + 1) % DATA_POINTS;
		count += (i == 0);
	}
	
	for (j=0; j<count; j++){
		printf("%d   %d\n", data[IDX(j, DATA_SUBMISSION)], data[IDX(j, DATA_BURST)]);
	}

	return 0;
}
